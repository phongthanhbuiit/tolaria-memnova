# F-041 diagnostic runs

Temporary `tests/integration/f041-diagnostic.spec.ts` copied the original spec with hooks; it was removed before final code/checks. Each run used WebKit, `--retries=0`, and 3 repeats of the blank-lines case. These instrumented runs are diagnostic, not acceptance measurements.

- `diagnostic.log`: page.route fetched react-virtuoso.js, used a WeakMap to compare props in internal `c(f,a)`; logged changed props and subscribed stream names. Console logging changed timing: 1/1 passed.
- `diagnostic-light.log`: replaced console traffic with `globalThis.f041Events`. In `c(f,a)`, recorded keys with changed reference and data length. In the useSyncExternalStore subscription, recorded stream name and listState bottom/count/item index/size/offset. On failure, afterEach read that array, the complete fatal overlay text, and took a screenshot. 2 failed / 1 passed. One failure recorded 302 events; the tail repeatedly published style/data with unchanged item geometry.
- `diagnostic-data.log`: additionally compared each entry against previous data at its index. Repeated source fields were aliases/belongsTo/relatedTo/relationships/outgoingLinks/properties/listPropertiesDisplay; other entries remained unchanged. 1 failed / 2 passed.
- `diagnostic-entry.log`: separate route on transformed useVaultLoader.ts inserted an event at the public updateEntry callback, recording path, patch and `new Error().stack`. 1 failed / 2 passed. The failing sample had two actual updateEntry calls: title/hasH1 in startTransition, then outgoingLinks/snippet/wordCount/modifiedAt after save.

These complementary samples plus the source updater and Virtuoso layout publishing code identify a replay feedback mechanism. Event counts from separate runs are not one synchronized trace. The uninstrumented HEAD run and final acceptance runs are the rate evidence.
